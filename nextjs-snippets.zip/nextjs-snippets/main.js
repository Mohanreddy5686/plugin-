// Add React component snippet
acode.addSnippet({
  name: "React Functional Component",
  body: "import React from 'react';\n\nconst ${1:Component} = () => {\n  return (\n    <div>\n      ${0}\n    </div>\n  );\n};\n\nexport default ${1:Component};",
  scope: "javascript,typescript,jsx,tsx"
});

// Add Next.js page component
acode.addSnippet({
  name: "Next.js Page",
  body: "import React from 'react';\n\nconst ${1:Page} = () => {\n  return (\n    <div>\n      ${0}\n    </div>\n  );\n};\n\nexport default ${1:Page};",
  scope: "javascript,typescript,jsx,tsx"
});

// Add Next.js API route
acode.addSnippet({
  name: "Next.js API Route",
  body: "export default function handler(req, res) {\n  res.status(200).json({ message: '${0:Hello World}' });\n}",
  scope: "javascript,typescript"
});

// Add getStaticProps snippet
acode.addSnippet({
  name: "getStaticProps",
  body: "export async function getStaticProps(context) {\n  return {\n    props: {\n      ${0}\n    },\n  };\n}",
  scope: "javascript,typescript"
});

// Add getServerSideProps snippet
acode.addSnippet({
  name: "getServerSideProps",
  body: "export async function getServerSideProps(context) {\n  return {\n    props: {\n      ${0}\n    },\n  };\n}",
  scope: "javascript,typescript"
});

// Add Head import snippet
acode.addSnippet({
  name: "Next Head Import",
  body: "import Head from 'next/head';\n\n<Head>\n  <title>${0:Page Title}</title>\n</Head>",
  scope: "javascript,typescript,jsx,tsx"
});

console.log("Next.js snippets plugin loaded!");
